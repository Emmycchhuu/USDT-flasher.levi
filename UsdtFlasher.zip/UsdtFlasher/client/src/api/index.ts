
// Mock API responses
const mockTransactions = [
  { hash: "0x123", amount: "1,000", status: "success", timestamp: Date.now() },
  { hash: "0x456", amount: "2,500", status: "success", timestamp: Date.now() - 3600000 }
];

export const fetchTransactions = async () => {
  return mockTransactions;
};

export const verifyLicense = async (key: string) => {
  return { valid: true, license: { key, active: true } };
};

export const simulateTransaction = async () => {
  return { success: true, txId: `0x${Math.random().toString(36).substr(2, 8)}` };
};

export const getChatResponse = async () => {
  return { reply: "This is a demo version. Please contact support for full features." };
};
