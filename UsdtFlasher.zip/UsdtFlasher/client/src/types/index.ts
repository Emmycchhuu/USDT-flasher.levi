export interface Transaction {
  id: string;
  hash: string;
  amount: string;
  sender: string;
  recipient: string;
  status: "PENDING" | "CONFIRMED" | "FAILED";
  timestamp: string;
}

export interface License {
  id: number;
  name: string;
  email: string;
  key: string;
  active: boolean;
  createdAt: string;
}

export interface InsertLicense {
  name: string;
  email: string;
  key: string;
}

export interface ChatMessage {
  id: string;
  text: string;
  sender: "user" | "bot";
  timestamp: string;
}

export interface FaqItem {
  id: number;
  question: string;
  answer: string;
  isOpen?: boolean;
}

export interface SimulateTransactionParams {
  sender: string;
  recipient: string;
  amount: string;
  speed: "slow" | "medium" | "fast";
}
