import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Transaction } from "../types";
import TransactionLine from "../components/TransactionLine";
import { useQuery } from "@tanstack/react-query";
// Import SVG as a component using Vite's features
import logoSvg from "../assets/logo.svg";

export default function Home() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);

  // Fetch mock transactions from the API
  const { data, isLoading } = useQuery({
    queryKey: ["/api/transactions"],
    staleTime: 10000, // refetch after 10 seconds
  });

  useEffect(() => {
    if (data) {
      setTransactions(data);
    }
  }, [data]);

  return (
    <>
      {/* Hero Section */}
      <section id="home" className="py-16 md:py-24 px-6">
        <div className="container mx-auto flex flex-col items-center">
          <div className="mb-8 w-32 h-32">
            <img src={logoSvg} alt="Levi Flasher Logo" className="w-full h-full" />
          </div>
          <h1 className="text-center font-orbitron font-bold text-3xl md:text-5xl lg:text-6xl mb-8 typewriter">
            <span className="text-white">Levi No1 Original</span>{" "}
            <span className="text-neon-pink">Usdt Flasher</span>
          </h1>
          <p className="text-center max-w-3xl text-lg md:text-xl mb-10">
            Experience the world of original usdt flasher with advance Python Programs.
          </p>
          <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-6">
            <Link href="/simulator">
              <a className="inline-flex items-center justify-center px-8 py-4 rounded bg-neon-purple text-white font-orbitron font-bold text-lg hover:shadow-neon-purple transition-shadow">
                TRY FLASH
                <i className="fas fa-angle-right ml-2"></i>
              </a>
            </Link>
            <Link href="/license">
              <a className="inline-flex items-center justify-center px-8 py-4 rounded border-2 border-neon-blue text-neon-blue font-orbitron font-bold text-lg hover:shadow-neon-blue transition-shadow">
                GET LICENSE
                <i className="fas fa-key ml-2"></i>
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Disclaimer */}
      <section className="py-8 px-6 bg-neon-red bg-opacity-10">
        <div className="container mx-auto">
          <div className="flex items-center justify-center">
            <i className="fas fa-exclamation-triangle text-2xl text-neon-red mr-4"></i>
            <p className="text-lg font-bold text-white">
              <span className="text-neon-red">DISCLAIMER:</span> This tool should not be used for scamming purposes 
              and should only be used for <span className="underline">Educational purposes only</span>. 
              We will not be held responsible for any damages caused by our tool.
            </p>
          </div>
        </div>
      </section>

      {/* Live Transactions */}
      <section className="py-12 px-6">
        <div className="container mx-auto">
          <h2 className="text-center font-orbitron text-neon-blue text-3xl md:text-4xl mb-10">
            LIVE BLOCKCHAIN DATA
          </h2>

          <div className="glass-card rounded-lg p-6 max-w-4xl mx-auto">
            <div className="overflow-hidden">
              {/* Transaction Data */}
              <div className="mb-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-neon-green font-tech">LATEST TRANSACTIONS</span>
                  <span className="text-neon-blue font-tech">TRC20 NETWORK</span>
                </div>

                {isLoading ? (
                  <div className="py-8 text-center">
                    <div className="inline-block animate-spin mr-2">
                      <i className="fas fa-circle-notch text-neon-blue"></i>
                    </div>
                    <span>Loading transactions...</span>
                  </div>
                ) : (
                  transactions.map((tx) => (
                    <TransactionLine key={tx.id} transaction={tx} />
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
