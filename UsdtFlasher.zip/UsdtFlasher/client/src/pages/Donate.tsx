import CopyToClipboard from "../components/CopyToClipboard";

export default function Donate() {
  return (
    <section id="donate" className="py-16 px-6">
      <div className="container mx-auto max-w-4xl">
        <h2 className="text-center font-orbitron text-neon-blue text-3xl md:text-4xl mb-4">
          SUPPORT THE PROJECT
        </h2>
        <p className="text-center max-w-2xl mx-auto mb-10 text-gray-400">
          You can donate our Projects to keep enjoying our work.
        </p>

        <div className="glass-card rounded-lg p-8 neon-border">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="font-orbitron text-neon-pink text-xl mb-6">
                DONATE USDT (TRC20)
              </h3>

              <div className="bg-dark-bg p-6 rounded-lg mb-6 border border-neon-blue">
                <p className="font-tech mb-3 text-sm text-gray-400">
                  DONATION ADDRESS:
                </p>
                <div className="relative">
                  <CopyToClipboard text="TWaB9s2nBVMbDaZaVNpAYMKXqzc6ZE26CY" className="bg-dark-gray border-neon-blue" />
                </div>
                <p className="text-sm text-gray-400 mt-3">
                  Your donation supports development of new flashing tools.
                </p>
              </div>

              <div>
                <h4 className="font-orbitron text-neon-green text-lg mb-3">
                  WHAT YOUR DONATION SUPPORTS:
                </h4>
                <ul className="space-y-2">
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-neon-green mt-1 mr-2"></i>
                    <span>Server costs and maintenance</span>
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-neon-green mt-1 mr-2"></i>
                    <span>Research into blockchain technologies</span>
                  </li>
                </ul>
              </div>
            </div>

            <div className="flex flex-col justify-center items-center p-6">
              <div className="text-center mb-6">
                <div className="inline-block p-2 bg-white rounded-lg mb-4">
                  <div className="w-48 h-48 bg-dark-bg flex items-center justify-center">
                    <svg
                      className="w-full h-full"
                      viewBox="0 0 256 256"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <rect width="256" height="256" fill="#0d0221" />
                      <path
                        d="M64 64h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm-96 8h8v8h-8zm96 0h8v8h-8zm-96 8h8v8h-8zm16 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm16 0h8v8h-8zm-96 8h8v8h-8zm16 0h8v8h-8zm64 0h8v8h-8zm16 0h8v8h-8zm-96 8h8v8h-8zm16 0h8v8h-8zm8 0h8v8h-8zm24 0h8v8h-8zm16 0h8v8h-8zm16 0h8v8h-8zm16 0h8v8h-8zm-96 8h8v8h-8zm16 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm24 0h8v8h-8zm32 0h8v8h-8zm8 0h8v8h-8zm-96 8h8v8h-8zm16 0h8v8h-8zm64 0h8v8h-8zm16 0h8v8h-8zm-96 8h8v8h-8zm16 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm16 0h8v8h-8zm-96 8h8v8h-8zm96 0h8v8h-8zm-96 8h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm-72 24h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm-64 8h8v8h-8zm8 0h8v8h-8zm24 0h8v8h-8zm8 0h8v8h-8zm16 0h8v8h-8zm8 0h8v8h-8zm-64 8h8v8h-8zm32 0h8v8h-8zm24 0h8v8h-8zm-48 8h8v8h-8zm16 0h8v8h-8zm16 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm-56 8h8v8h-8zm8 0h8v8h-8zm24 0h8v8h-8zm24 0h8v8h-8zm-48 8h8v8h-8zm16 0h8v8h-8zm8 0h8v8h-8zm16 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm-64 8h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm16 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm-64 8h8v8h-8zm16 0h8v8h-8zm40 0h8v8h-8zm-48 8h8v8h-8zm24 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm-72 8h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm16 0h8v8h-8zm8 0h8v8h-8zm16 0h8v8h-8zm8 0h8v8h-8zm16 0h8v8h-8zm-72 8h8v8h-8zm24 0h8v8h-8zm16 0h8v8h-8zm16 0h8v8h-8zm16 0h8v8h-8zm-80 8h8v8h-8zm16 0h8v8h-8zm8 0h8v8h-8zm24 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm16 0h8v8h-8zm-72 8h8v8h-8zm24 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm32 0h8v8h-8zm-80 8h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8zm16 0h8v8h-8zm8 0h8v8h-8zm8 0h8v8h-8z"
                        fill="#2de2e6"
                      />
                    </svg>
                  </div>
                </div>
                <p className="text-sm text-gray-400">Scan QR code to donate</p>
              </div>

              <div className="w-full glass-card rounded-lg p-4 border border-neon-green">
                <div className="text-center">
                  <p className="font-tech text-neon-green mb-2">
                    TOP DONORS THIS MONTH
                  </p>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="font-tech truncate">0x7a2d...4f5e1</span>
                      <span className="text-neon-blue">500 USDT</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-tech truncate">0x3b5d...8f4e2</span>
                      <span className="text-neon-blue">350 USDT</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-tech truncate">0xf4e2...1d7c3</span>
                      <span className="text-neon-blue">200 USDT</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
