import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { License } from "../types";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { nanoid } from "nanoid";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogClose
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow, 
} from "@/components/ui/table";
import CopyToClipboard from "../components/CopyToClipboard";

const formSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Please enter a valid email"),
  key: z.string().min(10, "License key must be at least 10 characters"),
});

export default function Admin() {
  const [licenses, setLicenses] = useState<License[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const { toast } = useToast();

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      key: `LEVI-${nanoid(16)}`,
    },
  });

  // Fetch licenses
  useEffect(() => {
    const fetchLicenses = async () => {
      try {
        setIsLoading(true);
        const data = await apiRequest<License[]>("/api/admin/licenses", { method: "GET" });
        setLicenses(data);
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to fetch licenses",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchLicenses();
  }, [toast]);

  // Toggle license status
  const toggleLicenseStatus = async (id: number) => {
    try {
      const updatedLicense = await apiRequest<License>(`/api/admin/licenses/toggle/${id}`, {
        method: "POST",
      });
      
      setLicenses(
        licenses.map((license) =>
          license.id === id ? updatedLicense : license
        )
      );
      
      toast({
        title: "Success",
        description: `License ${updatedLicense.active ? "activated" : "deactivated"} successfully`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update license status",
        variant: "destructive",
      });
    }
  };

  // Create license
  const onSubmit = async (values: z.infer<typeof formSchema>) => {
    try {
      const newLicense = await apiRequest<License>("/api/admin/licenses/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(values),
      });

      setLicenses([...licenses, newLicense]);
      setOpen(false);
      form.reset({
        name: "",
        email: "",
        key: `LEVI-${nanoid(16)}`,
      });
      
      toast({
        title: "Success",
        description: "License created successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create license",
        variant: "destructive",
      });
    }
  };

  // Generate new license key
  const generateKey = () => {
    form.setValue("key", `LEVI-${nanoid(16)}`);
  };

  return (
    <section className="py-16 px-6 bg-dark-bg min-h-screen">
      <div className="container mx-auto max-w-6xl">
        <div className="flex justify-between items-center mb-8">
          <h2 className="font-orbitron text-neon-green text-3xl md:text-4xl mb-2">
            ADMIN DASHBOARD
          </h2>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button variant="default" className="bg-neon-green text-black hover:bg-neon-green/80">
                Create License
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-dark-bg border-2 border-neon-green">
              <DialogHeader>
                <DialogTitle className="text-neon-green font-orbitron">Create New License</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-neon-blue">Full Name</FormLabel>
                        <FormControl>
                          <Input placeholder="John Doe" {...field} className="bg-dark-gray text-white" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-neon-blue">Email</FormLabel>
                        <FormControl>
                          <Input 
                            type="email" 
                            placeholder="user@example.com" 
                            {...field} 
                            className="bg-dark-gray text-white" 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="key"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-neon-blue">License Key</FormLabel>
                        <div className="flex gap-2">
                          <FormControl>
                            <Input {...field} className="bg-dark-gray text-white" />
                          </FormControl>
                          <Button 
                            type="button" 
                            onClick={generateKey}
                            className="bg-neon-purple hover:bg-neon-purple/80"
                          >
                            Generate
                          </Button>
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <DialogFooter className="mt-4">
                    <DialogClose asChild>
                      <Button type="button" variant="outline" className="border-neon-red text-neon-red">
                        Cancel
                      </Button>
                    </DialogClose>
                    <Button 
                      type="submit" 
                      className="bg-neon-green text-black hover:bg-neon-green/80"
                    >
                      Create License
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>

        <div className="glass-card rounded-lg p-6 border-2 border-neon-blue">
          <h3 className="font-orbitron text-neon-blue text-xl mb-6">
            LICENSE MANAGEMENT
          </h3>
          
          {isLoading ? (
            <div className="flex justify-center items-center h-40">
              <div className="animate-pulse font-tech text-neon-blue">Loading licenses...</div>
            </div>
          ) : licenses.length === 0 ? (
            <div className="text-center p-8 border border-dashed border-neon-blue rounded-lg">
              <p className="text-gray-400">No licenses found. Create your first license to get started.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader className="bg-dark-gray">
                  <TableRow>
                    <TableHead className="text-neon-blue">ID</TableHead>
                    <TableHead className="text-neon-blue">Name</TableHead>
                    <TableHead className="text-neon-blue">Email</TableHead>
                    <TableHead className="text-neon-blue">License Key</TableHead>
                    <TableHead className="text-neon-blue">Status</TableHead>
                    <TableHead className="text-neon-blue">Created</TableHead>
                    <TableHead className="text-neon-blue text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {licenses.map((license) => (
                    <TableRow key={license.id} className="border-b border-neon-blue/20">
                      <TableCell className="font-tech">{license.id}</TableCell>
                      <TableCell className="font-medium">{license.name}</TableCell>
                      <TableCell>{license.email}</TableCell>
                      <TableCell className="max-w-[200px]">
                        <div className="truncate flex items-center gap-2">
                          {license.key}
                          <CopyToClipboard text={license.key} className="ml-2" />
                        </div>
                      </TableCell>
                      <TableCell>
                        <span 
                          className={`py-1 px-2 rounded text-xs ${
                            license.active 
                              ? "bg-neon-green/20 text-neon-green" 
                              : "bg-neon-red/20 text-neon-red"
                          }`}
                        >
                          {license.active ? "ACTIVE" : "INACTIVE"}
                        </span>
                      </TableCell>
                      <TableCell className="text-sm">
                        {new Date(license.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          onClick={() => toggleLicenseStatus(license.id)}
                          variant="outline"
                          className={`border ${
                            license.active 
                              ? "border-neon-red text-neon-red" 
                              : "border-neon-green text-neon-green"
                          }`}
                          size="sm"
                        >
                          {license.active ? "Deactivate" : "Activate"}
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
        
        <div className="mt-10 p-4 bg-dark-gray rounded-lg border border-neon-red">
          <h4 className="font-orbitron text-neon-red mb-2">ADMIN CREDENTIALS</h4>
          <p className="text-gray-400 text-sm mb-4">
            This is a demonstration page. In a production environment, this would be protected with proper authentication.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-3 bg-dark-bg rounded border border-neon-blue/30">
              <div className="text-xs text-gray-500 mb-1">Default Admin Username</div>
              <div className="font-tech text-neon-blue">admin</div>
            </div>
            <div className="p-3 bg-dark-bg rounded border border-neon-blue/30">
              <div className="text-xs text-gray-500 mb-1">Default Admin Password</div>
              <div className="font-tech text-neon-blue">leviflasher123</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}