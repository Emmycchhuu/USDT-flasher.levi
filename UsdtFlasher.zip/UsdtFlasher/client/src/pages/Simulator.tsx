import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { useLicense } from "../contexts/LicenseContext";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { SimulateTransactionParams } from "../types";

export default function Simulator() {
  const { isLicensed } = useLicense();
  const { toast } = useToast();
  const [isSimulating, setIsSimulating] = useState(false);
  const [formData, setFormData] = useState<SimulateTransactionParams>({
    sender: "",
    recipient: "",
    amount: "",
    speed: "medium"
  });
  const [logs, setLogs] = useState<string[]>([
    "// Transaction logs will appear here"
  ]);
  const logsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (logsRef.current) {
      logsRef.current.scrollTop = logsRef.current.scrollHeight;
    }
  }, [logs]);

  const addLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs((prevLogs) => [...prevLogs, `[${timestamp}] ${message}`]);
  };

  const simulateTransaction = useMutation({
    mutationFn: async (data: SimulateTransactionParams) => {
      return apiRequest("POST", "/api/simulator/simulate", data);
    },
    onSuccess: async (response) => {
      const data = await response.json();
      setIsSimulating(true);

      // Show simulation logs
      addLog("Initializing transaction simulation...");
      addLog(`Sender: ${formData.sender || "0x7a2d...4f5e1"}`);
      addLog(`Recipient: ${formData.recipient || "0x3b5d...8f4e2"}`);
      addLog(`Amount: ${formData.amount || "1000"} USDT`);
      
      setTimeout(() => {
        addLog("Validating transaction parameters...");
      }, 1000);
      
      setTimeout(() => {
        addLog("Creating transaction object...");
      }, 2000);
      
      setTimeout(() => {
        addLog("Broadcasting to simulated network...");
      }, 3000);
      
      setTimeout(() => {
        addLog("Transaction successfully simulated!");
        addLog(`Simulation TX ID: ${data.txId}`);
        setIsSimulating(false);
        
        toast({
          title: "Simulation Complete",
          description: "Transaction simulation completed successfully!",
        });
      }, 5000);
    },
    onError: (error) => {
      toast({
        title: "Simulation Failed",
        description: error.message || "An error occurred during simulation",
        variant: "destructive",
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    simulateTransaction.mutate(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  return (
    <section id="simulator" className="py-16 px-6 bg-dark-bg">
      <div className="container mx-auto max-w-6xl">
        <h2 className="text-center font-orbitron text-neon-green text-3xl md:text-4xl mb-2">
          ORIGINAL USDT FLASHING GENERATOR
        </h2>
        <p className="text-center max-w-2xl mx-auto mb-10 text-gray-400">
          Experience unlimited Usdt(TRC20, BEP20, ERC20) flashing.
        </p>

        {!isLicensed ? (
          // License Required Message
          <div className="glass-card rounded-lg p-8 mb-10 border-2 border-neon-red">
            <div className="flex flex-col items-center text-center">
              <i className="fas fa-lock text-neon-red text-5xl mb-4 animate-pulse"></i>
              <h3 className="font-orbitron text-neon-red text-2xl mb-2">
                LICENSE REQUIRED
              </h3>
              <p className="mb-6">
                You need a valid license key to access the transaction flash tool.
              </p>
              <Link href="/license">
                <a className="inline-flex items-center justify-center px-8 py-3 rounded bg-neon-red text-white font-orbitron font-bold hover:shadow-neon-red transition-shadow">
                  GET LICENSE KEY
                </a>
              </Link>
            </div>
          </div>
        ) : (
          // Simulator Interface
          <div className="glass-card rounded-lg p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Transaction Form */}
              <div>
                <h3 className="font-orbitron text-neon-blue text-xl mb-6">
                  TRANSACTION DETAILS
                </h3>

                <form id="simulator-form" className="space-y-4" onSubmit={handleSubmit}>
                  <div>
                    <label className="block text-neon-purple mb-2 font-tech">
                      SENDER ADDRESS
                    </label>
                    <input
                      type="text"
                      name="sender"
                      value={formData.sender}
                      onChange={handleChange}
                      className="w-full bg-dark-bg border-2 border-neon-purple text-white px-4 py-3 rounded focus:outline-none focus:border-neon-pink focus:shadow-neon-purple transition-all font-tech"
                      placeholder="Enter sender's TRC20 address"
                    />
                  </div>

                  <div>
                    <label className="block text-neon-purple mb-2 font-tech">
                      RECIPIENT ADDRESS
                    </label>
                    <input
                      type="text"
                      name="recipient"
                      value={formData.recipient}
                      onChange={handleChange}
                      className="w-full bg-dark-bg border-2 border-neon-purple text-white px-4 py-3 rounded focus:outline-none focus:border-neon-pink focus:shadow-neon-purple transition-all font-tech"
                      placeholder="Enter recipient's TRC20 address"
                    />
                  </div>

                  <div>
                    <label className="block text-neon-purple mb-2 font-tech">
                      AMOUNT (USDT)
                    </label>
                    <input
                      type="number"
                      name="amount"
                      value={formData.amount}
                      onChange={handleChange}
                      className="w-full bg-dark-bg border-2 border-neon-purple text-white px-4 py-3 rounded focus:outline-none focus:border-neon-pink focus:shadow-neon-purple transition-all font-tech"
                      placeholder="Enter amount to transfer"
                    />
                  </div>

                  <div>
                    <label className="block text-neon-purple mb-2 font-tech">
                      TRANSACTION SPEED
                    </label>
                    <select
                      name="speed"
                      value={formData.speed}
                      onChange={handleChange}
                      className="w-full bg-dark-bg border-2 border-neon-purple text-white px-4 py-3 rounded focus:outline-none focus:border-neon-pink focus:shadow-neon-purple transition-all font-tech"
                    >
                      <option value="slow">Slow (Low Fee)</option>
                      <option value="medium">Medium (Standard Fee)</option>
                      <option value="fast">Fast (High Fee)</option>
                    </select>
                  </div>

                  <button
                    type="submit"
                    disabled={simulateTransaction.isPending || isSimulating}
                    className={`w-full font-orbitron font-bold text-dark-bg px-6 py-3 rounded transition-shadow mt-4 ${
                      simulateTransaction.isPending || isSimulating
                        ? "bg-gray-500 cursor-not-allowed"
                        : "bg-neon-green hover:shadow-neon-green"
                    }`}
                  >
                    {simulateTransaction.isPending || isSimulating ? (
                      <span className="flex items-center justify-center">
                        <i className="fas fa-circle-notch fa-spin mr-2"></i>
                        FLASHING...
                      </span>
                    ) : (
                      "START FLASH"
                    )}
                  </button>
                </form>
              </div>

              {/* Visualization Area */}
              <div>
                <h3 className="font-orbitron text-neon-pink text-xl mb-6">
                  TRANSACTION VISUALIZATION
                </h3>

                <div className="bg-dark-bg border-2 border-neon-blue rounded-lg h-80 p-4 flex items-center justify-center overflow-hidden">
                  {!isSimulating ? (
                    // Default state
                    <div className="text-center">
                      <i className="fas fa-broadcast-tower text-neon-blue text-4xl mb-4 animate-pulse"></i>
                      <p className="text-gray-400">
                        Transaction visualization will appear here once you start a flash.
                      </p>
                    </div>
                  ) : (
                    // Simulation active state with vertical flow
                    <div className="w-full h-full transaction-flow">
                      {/* Dynamic data particles - 15 random particles */}
                      {Array.from({ length: 15 }).map((_, i) => (
                        <div 
                          key={i}
                          className="data-particle"
                          style={{
                            left: `${Math.random() * 90 + 5}%`,
                            animationDelay: `${Math.random() * 2}s`,
                            height: `${Math.random() * 15 + 5}px`,
                            opacity: Math.random() * 0.5 + 0.3
                          }}
                        />
                      ))}
                      
                      <div className="w-full h-full flex flex-col justify-between relative p-3">
                        {/* Sender at top */}
                        <div className="self-start bg-dark-gray rounded-lg p-3 border border-neon-blue mb-2 z-10">
                          <div className="font-tech text-xs">SENDER</div>
                          <div className="text-neon-blue text-sm">
                            {formData.sender || "0x7a2d...4f5e1"}
                          </div>
                        </div>

                        {/* Amount in middle */}
                        <div className="self-center bg-dark-gray rounded-lg py-2 px-4 border border-neon-green z-10 mt-8 mb-8">
                          <div className="text-neon-green font-bold text-center">
                            {formData.amount || "1000"} USDT
                          </div>
                        </div>

                        {/* Recipient at bottom */}
                        <div className="self-end bg-dark-gray rounded-lg p-3 border border-neon-purple mt-2 z-10">
                          <div className="font-tech text-xs">RECIPIENT</div>
                          <div className="text-neon-pink text-sm">
                            {formData.recipient || "0x3b5d...8f4e2"}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <div 
                  ref={logsRef}
                  className="mt-6 bg-dark-bg border border-neon-blue rounded-lg p-4 h-32 overflow-y-auto font-tech text-sm"
                >
                  {logs.map((log, index) => (
                    <div 
                      key={index} 
                      className={
                        log.includes("Initializing") || log.includes("successfully") 
                          ? "text-neon-green" 
                          : log.includes("Broadcasting") 
                            ? "text-neon-pink" 
                            : log.includes("Validating") || log.includes("Creating") 
                              ? "text-neon-blue" 
                              : "text-gray-400"
                      }
                    >
                      {log}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Coming Soon - BTC Flasher */}
        <div className="mt-16 glass-card rounded-lg p-8 border-2 border-neon-purple">
          <div className="flex flex-col items-center text-center">
            <div className="flex items-center justify-center w-16 h-16 rounded-full bg-neon-purple bg-opacity-20 mb-4">
              <i className="fab fa-bitcoin text-neon-purple text-2xl animate-pulse"></i>
            </div>
            <h3 className="font-orbitron text-neon-purple text-2xl mb-2">
              BTC FLASHER COMING SOON
            </h3>
            <p className="max-w-lg">
              We're working on our Bitcoin transaction flash tool. Current license holders will get free access!
            </p>
            <div className="mt-6 bg-dark-bg rounded-lg px-6 py-3 inline-flex items-center">
              <span className="inline-block w-3 h-3 bg-neon-red rounded-full mr-3 animate-pulse"></span>
              <span className="font-tech">ESTIMATED RELEASE: Q2 2025</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
