
import React from "react";
import AuthButtons from "../components/AuthButtons";

export default function Login() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-dark-bg">
      <div className="glass-card p-8 rounded-lg neon-border max-w-md w-full">
        <h2 className="text-2xl font-orbitron text-neon-blue text-center mb-8">
          Sign In to Continue
        </h2>
        <AuthButtons />
      </div>
    </div>
  );
}
