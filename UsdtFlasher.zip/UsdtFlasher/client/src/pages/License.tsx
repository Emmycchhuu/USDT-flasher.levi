import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useLicense } from "../contexts/LicenseContext";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import CopyToClipboard from "../components/CopyToClipboard";

export default function License() {
  const { isLicensed, verifyLicense } = useLicense();
  const { toast } = useToast();
  const [licenseKey, setLicenseKey] = useState("");
  const [purchaseForm, setPurchaseForm] = useState({
    name: "",
    email: "",
  });

  const handleLicenseVerify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!licenseKey.trim()) {
      toast({
        title: "Error",
        description: "Please enter a license key",
        variant: "destructive",
      });
      return;
    }

    await verifyLicense(licenseKey);
  };

  const verifyPayment = useMutation({
    mutationFn: async (formData: { name: string; email: string }) => {
      return apiRequest("POST", "/api/license/verify-payment", formData);
    },
    onSuccess: () => {
      toast({
        title: "Payment verification submitted",
        description: "We will verify your payment and send your license key to your email address.",
      });
      setPurchaseForm({
        name: "",
        email: "",
      });
    },
    onError: (error) => {
      toast({
        title: "Verification failed",
        description: error.message || "Failed to process your request.",
        variant: "destructive",
      });
    }
  });

  const handlePurchaseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!purchaseForm.name.trim() || !purchaseForm.email.trim()) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    verifyPayment.mutate(purchaseForm);
  };

  const handlePurchaseChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setPurchaseForm((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  return (
    <section id="license" className="py-16 px-6">
      <div className="container mx-auto max-w-6xl">
        <h2 className="text-center font-orbitron text-neon-pink text-3xl md:text-4xl mb-10">
          LICENSE VERIFICATION
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {/* License Key Verification */}
          <div className="glass-card rounded-lg p-8 neon-border">
            <h3 className="font-orbitron text-neon-blue text-2xl mb-6">
              Already Have a License Key?
            </h3>

            <form className="space-y-6" onSubmit={handleLicenseVerify}>
              <div>
                <label className="block text-neon-purple mb-2 font-tech">
                  YOUR LICENSE KEY
                </label>
                <input
                  type="text"
                  value={licenseKey}
                  onChange={(e) => setLicenseKey(e.target.value)}
                  className="w-full bg-dark-bg border-2 border-neon-blue text-white px-4 py-3 rounded focus:outline-none focus:border-neon-pink focus:shadow-neon-blue transition-all font-tech"
                  placeholder="Enter your license key"
                />
              </div>

              <button
                type="submit"
                className={`w-full font-orbitron font-bold px-6 py-3 rounded transition-shadow ${
                  isLicensed
                    ? "bg-neon-green text-dark-bg"
                    : "bg-neon-blue text-dark-bg hover:shadow-neon-blue"
                }`}
                disabled={isLicensed}
              >
                {isLicensed ? (
                  <span>
                    LICENSE VERIFIED <i className="fas fa-check ml-2"></i>
                  </span>
                ) : (
                  "VERIFY KEY"
                )}
              </button>

              <p className="text-sm text-center text-gray-400 mt-4">
                Your license key provides lifetime access to all current and future flash tools.
              </p>
            </form>
          </div>

          {/* Purchase License */}
          <div className="glass-card rounded-lg p-8 neon-border">
            <h3 className="font-orbitron text-neon-pink text-2xl mb-6">
              Get Your License Key
            </h3>

            <div className="mb-6 bg-dark-gray bg-opacity-50 rounded-lg p-4">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <i className="fas fa-star text-neon-green mr-2"></i>
                </div>
                <div>
                  <h4 className="font-orbitron text-neon-green mb-2">LIFETIME LICENSE</h4>
                  <p className="mb-2">One-time payment for full access to all flash tools</p>
                  <p className="text-2xl font-bold">
                    750 USDT <span className="text-sm font-normal">(TRC20)</span>
                  </p>
                </div>
              </div>
            </div>

            <form className="space-y-4" onSubmit={handlePurchaseSubmit}>
              <div>
                <label className="block text-neon-purple mb-2 font-tech">
                  YOUR NAME
                </label>
                <input
                  type="text"
                  name="name"
                  value={purchaseForm.name}
                  onChange={handlePurchaseChange}
                  className="w-full bg-dark-bg border-2 border-neon-purple text-white px-4 py-3 rounded focus:outline-none focus:border-neon-pink focus:shadow-neon-purple transition-all"
                  placeholder="Enter your full name"
                />
              </div>

              <div>
                <label className="block text-neon-purple mb-2 font-tech">
                  YOUR EMAIL
                </label>
                <input
                  type="email"
                  name="email"
                  value={purchaseForm.email}
                  onChange={handlePurchaseChange}
                  className="w-full bg-dark-bg border-2 border-neon-purple text-white px-4 py-3 rounded focus:outline-none focus:border-neon-pink focus:shadow-neon-purple transition-all"
                  placeholder="Enter your email address"
                />
                <p className="text-sm text-gray-400 mt-1">
                  License key will be sent to this email after payment.
                </p>
              </div>

              <div className="pt-4">
                <label className="block text-neon-purple mb-2 font-tech">
                  PAYMENT ADDRESS
                </label>
                <div className="relative">
                  <CopyToClipboard text="TWaB9s2nBVMbDaZaVNpAYMKXqzc6ZE26CY" />
                </div>
                <p className="text-sm text-gray-400 mt-1">
                  Send exactly 750 USDT (TRC20) to this address.
                </p>
              </div>

              <button
                type="submit"
                disabled={verifyPayment.isPending}
                className={`w-full font-orbitron font-bold text-white px-6 py-3 rounded hover:shadow-neon-pink transition-shadow mt-4 ${
                  verifyPayment.isPending
                    ? "bg-gray-500 cursor-not-allowed"
                    : "bg-neon-pink"
                }`}
              >
                {verifyPayment.isPending ? (
                  <span className="flex items-center justify-center">
                    <i className="fas fa-circle-notch fa-spin mr-2"></i>
                    PROCESSING...
                  </span>
                ) : (
                  "I'VE SENT THE PAYMENT"
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
