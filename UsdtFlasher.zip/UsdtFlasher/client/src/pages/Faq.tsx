import { useState, useEffect } from "react";
import { FaqItem } from "../types";
import { useQuery } from "@tanstack/react-query";

export default function Faq() {
  const [faqItems, setFaqItems] = useState<FaqItem[]>([]);

  const { data } = useQuery({
    queryKey: ["/api/faq"],
  });

  useEffect(() => {
    if (data) {
      setFaqItems(data.map((item: FaqItem) => ({ ...item, isOpen: false })));
    }
  }, [data]);

  const toggleFaq = (id: number) => {
    setFaqItems(
      faqItems.map((item) => 
        item.id === id ? { ...item, isOpen: !item.isOpen } : item
      )
    );
  };

  return (
    <section id="faq" className="py-16 px-6 bg-dark-bg">
      <div className="container mx-auto max-w-4xl">
        <h2 className="text-center font-orbitron text-neon-pink text-3xl md:text-4xl mb-10">
          FREQUENTLY ASKED QUESTIONS
        </h2>

        <div className="space-y-6">
          {faqItems.length === 0 ? (
            <div className="text-center py-10">
              <div className="inline-block animate-spin mr-2">
                <i className="fas fa-circle-notch text-neon-blue"></i>
              </div>
              <span>Loading FAQs...</span>
            </div>
          ) : (
            faqItems.map((item) => (
              <div key={item.id} className="glass-card rounded-lg p-6">
                <button
                  className="flex justify-between items-center w-full text-left focus:outline-none"
                  onClick={() => toggleFaq(item.id)}
                >
                  <h3 className="font-orbitron text-neon-blue text-xl">
                    {item.question}
                  </h3>
                  <i
                    className={`fas fa-chevron-down text-neon-blue transition-transform ${
                      item.isOpen ? "transform rotate-180" : ""
                    }`}
                  ></i>
                </button>
                {item.isOpen && (
                  <div className="mt-4 text-gray-300">
                    <p>{item.answer}</p>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </section>
  );
}
