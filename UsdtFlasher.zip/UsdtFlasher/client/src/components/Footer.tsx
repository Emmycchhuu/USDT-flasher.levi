import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="py-10 px-6 border-t border-neon-blue">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          <div>
            <div className="text-3xl font-orbitron font-bold text-white mb-4">
              <span className="text-neon-purple">LEVI</span>{" "}
              <span className="text-neon-blue">FLASHER</span>
            </div>
            <p className="text-gray-400 mb-4">
              A blockchain transaction simulator.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-neon-blue hover:text-neon-pink">
                <i className="fab fa-telegram"></i>
              </a>
              <a href="#" className="text-neon-blue hover:text-neon-pink">
                <i className="fab fa-discord"></i>
              </a>
              <a href="#" className="text-neon-blue hover:text-neon-pink">
                <i className="fab fa-twitter"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="font-orbitron text-neon-pink text-lg mb-4">QUICK LINKS</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/">
                  <a className="text-gray-400 hover:text-neon-blue">Home</a>
                </Link>
              </li>
              <li>
                <Link href="/simulator">
                  <a className="text-gray-400 hover:text-neon-blue">Flash</a>
                </Link>
              </li>
              <li>
                <Link href="/license">
                  <a className="text-gray-400 hover:text-neon-blue">License</a>
                </Link>
              </li>
              <li>
                <Link href="/donate">
                  <a className="text-gray-400 hover:text-neon-blue">Donate</a>
                </Link>
              </li>
              <li>
                <Link href="/faq">
                  <a className="text-gray-400 hover:text-neon-blue">FAQ</a>
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-orbitron text-neon-green text-lg mb-4">LEGAL</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-400 hover:text-neon-blue">
                  Terms of Service
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-neon-blue">
                  Privacy Policy
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-neon-blue">
                  Disclaimer
                </a>
              </li>
            </ul>
            <div className="mt-6 p-3 bg-dark-bg rounded-lg border border-neon-red text-sm">
              <p className="text-neon-red font-bold">WARNING</p>
              <p className="text-gray-400">
                This tool should not be used for scamming purposes and should only be used for Educational purposes only. We will not be held responsible for any damages caused by our tool.
              </p>
            </div>
          </div>
        </div>
        
        <div className="mt-10 pt-6 border-t border-gray-800 text-center text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} Levi Flasher. All rights reserved.</p>
          <p className="mt-1">
            For educational purposes only. Not affiliated with any blockchain or financial institution.
          </p>
        </div>
      </div>
    </footer>
  );
}
