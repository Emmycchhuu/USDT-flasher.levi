import { useState, useRef, useEffect } from "react";
import { v4 as uuidv4 } from "uuid";
import { ChatMessage } from "../types";

export default function ChatBot() {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      text: "Hello! I'm your Levi Assistant. How can I help you with our USDT Flash today?",
      sender: "bot",
      timestamp: new Date().toISOString()
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const toggleChat = () => {
    setIsChatOpen(!isChatOpen);
  };

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!inputValue.trim()) return;
    
    const userMessage: ChatMessage = {
      id: uuidv4(),
      text: inputValue,
      sender: "user",
      timestamp: new Date().toISOString()
    };
    
    setMessages([...messages, userMessage]);
    setInputValue("");
    
    // Simulate bot thinking
    setTimeout(async () => {
      try {
        const response = await fetch("/api/chatbot", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ message: userMessage.text }),
        });
        
        if (!response.ok) {
          throw new Error("Failed to get response");
        }
        
        const data = await response.json();
        
        const botMessage: ChatMessage = {
          id: uuidv4(),
          text: data.reply,
          sender: "bot",
          timestamp: new Date().toISOString()
        };
        
        setMessages(prevMessages => [...prevMessages, botMessage]);
      } catch (error) {
        // Fallback response in case of error
        const botMessage: ChatMessage = {
          id: uuidv4(),
          text: "I'm sorry, I'm having trouble connecting to my knowledge base right now. Please try again later.",
          sender: "bot",
          timestamp: new Date().toISOString()
        };
        
        setMessages(prevMessages => [...prevMessages, botMessage]);
      }
    }, 1000);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Chat Button */}
      <button
        onClick={toggleChat}
        className="w-16 h-16 rounded-full bg-neon-purple shadow-neon-purple flex items-center justify-center"
      >
        <i className="fas fa-robot text-2xl text-white"></i>
      </button>
      
      {/* Chat Interface */}
      <div 
        className={`glass-card rounded-lg w-80 md:w-96 h-96 fixed bottom-24 right-6 flex flex-col overflow-hidden border border-neon-purple ${
          isChatOpen ? "" : "hidden"
        }`}
      >
        {/* Chat Header */}
        <div className="bg-neon-purple p-4">
          <div className="flex items-center">
            <i className="fas fa-robot text-white mr-2"></i>
            <h3 className="font-orbitron text-white">LEVI ASSISTANT</h3>
            <button
              onClick={toggleChat}
              className="ml-auto text-white hover:text-neon-blue"
            >
              <i className="fas fa-times"></i>
            </button>
          </div>
        </div>
        
        {/* Chat Messages */}
        <div className="flex-1 p-4 overflow-y-auto bg-dark-bg bg-opacity-90">
          {messages.map((message) => (
            <div 
              key={message.id} 
              className="chat-message mb-4"
            >
              {message.sender === "bot" ? (
                <div className="flex items-start">
                  <div className="flex-shrink-0 mr-2">
                    <div className="w-8 h-8 rounded-full bg-neon-purple flex items-center justify-center">
                      <i className="fas fa-robot text-white text-xs"></i>
                    </div>
                  </div>
                  <div className="bg-neon-purple bg-opacity-20 rounded-lg p-3 max-w-[80%]">
                    <p>{message.text}</p>
                  </div>
                </div>
              ) : (
                <div className="flex justify-end">
                  <div className="bg-neon-blue bg-opacity-20 rounded-lg p-3 max-w-[80%]">
                    <p>{message.text}</p>
                  </div>
                </div>
              )}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
        
        {/* Chat Input */}
        <div className="p-3 border-t border-neon-purple">
          <form className="flex" onSubmit={handleSendMessage}>
            <input
              type="text"
              className="flex-1 bg-dark-bg border border-neon-blue rounded-l-md px-4 py-2 text-white focus:outline-none focus:border-neon-purple"
              placeholder="Type your question..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
            />
            <button
              type="submit"
              className="bg-neon-purple px-4 py-2 rounded-r-md text-white hover:shadow-neon-purple transition-shadow"
            >
              <i className="fas fa-paper-plane"></i>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
