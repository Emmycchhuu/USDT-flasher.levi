
import React from "react";

export default function AuthButtons() {
  return (
    <div className="flex flex-col space-y-4">
      <a 
        href="/auth/google"
        className="px-6 py-3 bg-white text-gray-800 rounded-lg flex items-center justify-center space-x-2 hover:bg-gray-100"
      >
        <i className="fab fa-google"></i>
        <span>Continue with Google</span>
      </a>
      <a
        href="/auth/github"
        className="px-6 py-3 bg-gray-800 text-white rounded-lg flex items-center justify-center space-x-2 hover:bg-gray-700"
      >
        <i className="fab fa-github"></i>
        <span>Continue with GitHub</span>
      </a>
    </div>
  );
}
