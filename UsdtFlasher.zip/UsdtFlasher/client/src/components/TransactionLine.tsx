import { Transaction } from "../types";

interface TransactionLineProps {
  transaction: Transaction;
}

export default function TransactionLine({ transaction }: TransactionLineProps) {
  return (
    <div className="transaction-line border-b border-neon-blue border-opacity-30 py-3 grid grid-cols-4 gap-2 mb-2 animate-fadeIn">
      <div className="text-xs md:text-sm font-tech truncate">{transaction.hash}</div>
      <div className="text-xs md:text-sm text-neon-blue">{transaction.amount} USDT</div>
      <div className="text-xs md:text-sm truncate">
        {`${transaction.sender.substring(0, 6)}...${transaction.sender.substring(transaction.sender.length - 5)} → 
        ${transaction.recipient.substring(0, 6)}...${transaction.recipient.substring(transaction.recipient.length - 5)}`}
      </div>
      <div className="text-xs md:text-sm text-neon-green">{transaction.status}</div>
    </div>
  );
}
