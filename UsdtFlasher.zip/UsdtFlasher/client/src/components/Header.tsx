import { Link, useLocation } from "wouter";

export default function Header() {
  const [location] = useLocation();

  const navItems = [
    { label: "HOME", href: "/" },
    { label: "FLASH", href: "/simulator" },
    { label: "LICENSE", href: "/license" },
    { label: "DONATE", href: "/donate" },
  ];

  return (
    <header className="w-full py-4 px-6 bg-dark-bg border-b border-neon-blue">
      <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center mb-4 md:mb-0">
          <Link href="/">
            <div className="text-3xl font-orbitron font-bold text-white animate-glow cursor-pointer">
              <span className="text-neon-purple">LEVI</span>{" "}
              <span className="text-neon-blue">USDT FLASHER</span>
            </div>
          </Link>
        </div>
        <nav>
          <ul className="flex space-x-6 font-tech">
            {navItems.map((item) => (
              <li key={item.href}>
                <Link href={item.href}>
                  <div 
                    className={`hover:text-neon-pink transition-colors cursor-pointer ${
                      location === item.href ? "text-neon-pink" : "text-neon-blue"
                    }`}
                  >
                    {item.label}
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
}