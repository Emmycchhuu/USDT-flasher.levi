import { useState } from "react";

interface CopyToClipboardProps {
  text: string;
  className?: string;
}

export default function CopyToClipboard({ text, className = "" }: CopyToClipboardProps) {
  const [copied, setCopied] = useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    
    setTimeout(() => {
      setCopied(false);
    }, 2000);
  };

  return (
    <div className="relative w-full">
      <input
        type="text"
        value={text}
        readOnly
        className={`w-full bg-dark-bg border-2 border-neon-green text-neon-green px-4 py-3 rounded focus:outline-none font-tech ${className}`}
      />
      <button
        type="button"
        onClick={copyToClipboard}
        className="absolute right-2 top-1/2 transform -translate-y-1/2 text-neon-green hover:text-neon-pink"
      >
        {copied ? (
          <i className="fas fa-check text-neon-green"></i>
        ) : (
          <i className="fas fa-copy"></i>
        )}
      </button>
    </div>
  );
}
