import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useToast } from "@/hooks/use-toast";

interface LicenseContextType {
  isLicensed: boolean;
  licenseKey: string | null;
  verifyLicense: (key: string) => Promise<boolean>;
  setLicenseKey: (key: string | null) => void;
}

const LicenseContext = createContext<LicenseContextType | undefined>(undefined);

export function LicenseProvider({ children }: { children: ReactNode }) {
  const [isLicensed, setIsLicensed] = useState<boolean>(false);
  const [licenseKey, setLicenseKey] = useState<string | null>(null);
  const { toast } = useToast();

  // Check for saved license key in localStorage on initial load
  useEffect(() => {
    const savedKey = localStorage.getItem("licenseKey");
    if (savedKey) {
      verifyLicense(savedKey);
    }
  }, []);

  const verifyLicense = async (key: string): Promise<boolean> => {
    try {
      const response = await fetch("/api/license/verify", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ key }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        toast({
          title: "License verification failed",
          description: errorData.message || "Invalid license key",
          variant: "destructive",
        });
        return false;
      }

      const data = await response.json();
      if (data.valid) {
        setIsLicensed(true);
        setLicenseKey(key);
        localStorage.setItem("licenseKey", key);
        toast({
          title: "License verified",
          description: "You now have full access to the flash tool",
          variant: "default",
        });
        return true;
      } else {
        toast({
          title: "Invalid license key",
          description: data.message || "Please purchase a license or try again",
          variant: "destructive",
        });
        return false;
      }
    } catch (error) {
      toast({
        title: "Verification error",
        description: "Could not connect to license server",
        variant: "destructive",
      });
      return false;
    }
  };

  const contextValue: LicenseContextType = {
    isLicensed,
    licenseKey,
    verifyLicense,
    setLicenseKey: (key: string | null) => {
      setLicenseKey(key);
      if (key === null) {
        setIsLicensed(false);
        localStorage.removeItem("licenseKey");
      }
    },
  };

  return (
    <LicenseContext.Provider value={contextValue}>
      {children}
    </LicenseContext.Provider>
  );
}

export function useLicense() {
  const context = useContext(LicenseContext);
  if (context === undefined) {
    throw new Error("useLicense must be used within a LicenseProvider");
  }
  return context;
}
