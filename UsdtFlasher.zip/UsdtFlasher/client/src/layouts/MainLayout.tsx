import { ReactNode, useEffect } from "react";
import Header from "../components/Header";
import Footer from "../components/Footer";
import ChatBot from "../components/ChatBot";
import { useLocation } from "wouter";

interface MainLayoutProps {
  children: ReactNode;
}

export default function MainLayout({ children }: MainLayoutProps) {
  const [location] = useLocation();

  useEffect(() => {
    // Scroll to top on route change
    window.scrollTo(0, 0);
  }, [location]);

  return (
    <div className="min-h-screen font-rajdhani text-white flex flex-col cyberpunk-bg">
      <Header />
      <main className="flex-grow">
        {children}
      </main>
      <Footer />
      <ChatBot />
      
      <style jsx global>{`
        .cyberpunk-bg {
          background-color: hsl(var(--background));
          background-image: 
            radial-gradient(hsl(var(--chart-1)) 1px, transparent 1px),
            radial-gradient(hsl(var(--chart-2)) 1px, transparent 1px);
          background-size: 50px 50px;
          background-position: 0 0, 25px 25px;
          position: relative;
        }
        
        .cyberpunk-bg::before {
          content: "";
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(13, 2, 33, 0.85);
          z-index: -1;
        }
        
        .glass-card {
          background: rgba(13, 2, 33, 0.7);
          backdrop-filter: blur(10px);
          border: 1px solid rgba(184, 41, 232, 0.3);
          box-shadow: 0 0 15px rgba(45, 226, 230, 0.3);
        }
        
        .neon-border {
          position: relative;
        }
        
        .neon-border::before {
          content: '';
          position: absolute;
          top: -2px;
          left: -2px;
          right: -2px;
          bottom: -2px;
          border: 2px solid hsl(var(--chart-1));
          z-index: -1;
          animation: borderGlow 2s ease-in-out infinite alternate;
        }
        
        @keyframes borderGlow {
          0% { box-shadow: 0 0 5px hsl(var(--chart-1)), 0 0 10px hsl(var(--chart-1)); }
          100% { box-shadow: 0 0 10px hsl(var(--chart-1)), 0 0 20px hsl(var(--chart-1)), 0 0 30px hsl(var(--chart-1)); }
        }
        
        .typewriter {
          overflow: hidden;
          border-right: .15em solid hsl(var(--chart-1));
          white-space: nowrap;
          margin: 0 auto;
          letter-spacing: .1em;
          animation: typing 3.5s steps(40, end), blink-caret .75s step-end infinite;
        }
        
        @keyframes typing {
          from { width: 0 }
          to { width: 100% }
        }
        
        @keyframes blink-caret {
          from, to { border-color: transparent }
          50% { border-color: hsl(var(--chart-1)) }
        }
        
        .transaction-line {
          animation: slidein 3s infinite;
        }
        
        @keyframes slidein {
          0% { transform: translateX(-100%); opacity: 0; }
          20% { opacity: 1; }
          80% { opacity: 1; }
          100% { transform: translateX(100%); opacity: 0; }
        }
        
        .chat-message {
          overflow: hidden;
          animation: typing 2s steps(40, end);
        }
        
        .animate-glow {
          animation: glow 1.5s ease-in-out infinite alternate;
        }
        
        .animate-flicker {
          animation: flicker 1.5s infinite alternate;
        }
        
        @keyframes glow {
          0% { text-shadow: 0 0 5px #fff, 0 0 10px #fff, 0 0 15px hsl(var(--chart-1)), 0 0 20px hsl(var(--chart-1)); }
          100% { text-shadow: 0 0 10px #fff, 0 0 20px #fff, 0 0 30px hsl(var(--chart-1)), 0 0 40px hsl(var(--chart-1)); }
        }
        
        @keyframes flicker {
          0%, 18%, 22%, 25%, 53%, 57%, 100% { opacity: 1; }
          20%, 24%, 55% { opacity: 0.5; }
        }
        
        .font-orbitron {
          font-family: 'Orbitron', sans-serif;
        }
        
        .font-rajdhani {
          font-family: 'Rajdhani', sans-serif;
        }
        
        .font-tech {
          font-family: 'Share Tech Mono', monospace;
        }
        
        .text-neon-purple {
          color: #b829e8;
        }
        
        .text-neon-blue {
          color: #2de2e6;
        }
        
        .text-neon-pink {
          color: #f706cf;
        }
        
        .text-neon-green {
          color: #00ff00;
        }
        
        .text-neon-red {
          color: #ff0033;
        }
        
        .bg-neon-purple {
          background-color: #b829e8;
        }
        
        .bg-neon-blue {
          background-color: #2de2e6;
        }
        
        .bg-neon-pink {
          background-color: #f706cf;
        }
        
        .bg-neon-green {
          background-color: #00ff00;
        }
        
        .bg-neon-red {
          background-color: #ff0033;
        }
        
        .bg-dark-bg {
          background-color: #0d0221;
        }
        
        .bg-dark-gray {
          background-color: #333333;
        }
        
        .border-neon-purple {
          border-color: #b829e8;
        }
        
        .border-neon-blue {
          border-color: #2de2e6;
        }
        
        .border-neon-pink {
          border-color: #f706cf;
        }
        
        .border-neon-green {
          border-color: #00ff00;
        }
        
        .border-neon-red {
          border-color: #ff0033;
        }
        
        .hover\:shadow-neon-purple:hover {
          box-shadow: 0 0 5px #b829e8, 0 0 10px #b829e8, 0 0 15px #b829e8;
        }
        
        .hover\:shadow-neon-blue:hover {
          box-shadow: 0 0 5px #2de2e6, 0 0 10px #2de2e6, 0 0 15px #2de2e6;
        }
        
        .hover\:shadow-neon-pink:hover {
          box-shadow: 0 0 5px #f706cf, 0 0 10px #f706cf, 0 0 15px #f706cf;
        }
        
        .hover\:shadow-neon-green:hover {
          box-shadow: 0 0 5px #00ff00, 0 0 10px #00ff00, 0 0 15px #00ff00;
        }
        
        .hover\:shadow-neon-red:hover {
          box-shadow: 0 0 5px #ff0033, 0 0 10px #ff0033, 0 0 15px #ff0033;
        }
      `}</style>
    </div>
  );
}
