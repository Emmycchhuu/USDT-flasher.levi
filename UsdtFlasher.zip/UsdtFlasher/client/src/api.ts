
// Mock data and functions to replace server API calls
const MOCK_TRANSACTIONS = [
  { hash: "0x8ry4KOl2du", amount: "1,250", status: "success", timestamp: Date.now() },
  { hash: "0x9ty4LOl3eu", amount: "2,500", status: "pending", timestamp: Date.now() - 3600000 }
];

export const verifyLicense = async () => ({ valid: true });
export const getTransactions = async () => MOCK_TRANSACTIONS;
export const simulateTransaction = async () => ({ success: true, hash: "0x" + Math.random().toString(36).substring(7) });
