import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const licenses = pgTable("licenses", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  key: text("key").notNull().unique(),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertLicenseSchema = createInsertSchema(licenses).pick({
  name: true,
  email: true,
  key: true,
});

export type InsertLicense = z.infer<typeof insertLicenseSchema>;
export type License = typeof licenses.$inferSelect;

export const faqItems = pgTable("faq_items", {
  id: serial("id").primaryKey(),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
});

export const insertFaqItemSchema = createInsertSchema(faqItems).pick({
  question: true,
  answer: true,
});

export type InsertFaqItem = z.infer<typeof insertFaqItemSchema>;
export type FaqItem = typeof faqItems.$inferSelect;

export const mockTransactions = pgTable("mock_transactions", {
  id: serial("id").primaryKey(),
  hash: text("hash").notNull(),
  amount: text("amount").notNull(),
  sender: text("sender").notNull(),
  recipient: text("recipient").notNull(),
  status: text("status").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertMockTransactionSchema = createInsertSchema(mockTransactions).pick({
  hash: true,
  amount: true,
  sender: true,
  recipient: true,
  status: true,
});

export type InsertMockTransaction = z.infer<typeof insertMockTransactionSchema>;
export type MockTransaction = typeof mockTransactions.$inferSelect;
