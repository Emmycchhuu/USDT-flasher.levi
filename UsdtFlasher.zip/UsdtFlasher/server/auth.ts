
import { Express } from "express";
import passport from "passport";
import { Strategy as GoogleStrategy } from "passport-google-oauth20";
import { Strategy as GitHubStrategy } from "passport-github2";
import jwt from "jsonwebtoken";
import { storage } from "./storage";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

export function setupAuth(app: Express) {
  passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID!,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    callbackURL: "/auth/google/callback"
  }, async (accessToken, refreshToken, profile, done) => {
    try {
      let user = await storage.getUserByEmail(profile.emails![0].value);
      if (!user) {
        user = await storage.createUser({
          email: profile.emails![0].value,
          name: profile.displayName,
          provider: "google"
        });
      }
      return done(null, user);
    } catch (error) {
      return done(error as Error);
    }
  }));

  passport.use(new GitHubStrategy({
    clientID: process.env.GITHUB_CLIENT_ID!,
    clientSecret: process.env.GITHUB_CLIENT_SECRET!,
    callbackURL: "/auth/github/callback"
  }, async (accessToken, refreshToken, profile, done) => {
    try {
      let user = await storage.getUserByEmail(profile.emails![0].value);
      if (!user) {
        user = await storage.createUser({
          email: profile.emails![0].value,
          name: profile.displayName,
          provider: "github"
        });
      }
      return done(null, user);
    } catch (error) {
      return done(error as Error);
    }
  }));

  app.use(passport.initialize());

  // Auth routes
  app.get("/auth/google", passport.authenticate("google", { scope: ["profile", "email"] }));
  app.get("/auth/github", passport.authenticate("github", { scope: ["user:email"] }));

  app.get("/auth/google/callback", passport.authenticate("google", { session: false }), 
    (req, res) => {
      const token = jwt.sign({ userId: req.user.id }, JWT_SECRET);
      res.redirect(`/?token=${token}`);
    }
  );

  app.get("/auth/github/callback", passport.authenticate("github", { session: false }), 
    (req, res) => {
      const token = jwt.sign({ userId: req.user.id }, JWT_SECRET);
      res.redirect(`/?token=${token}`);
    }
  );
}
