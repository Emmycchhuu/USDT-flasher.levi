import { 
  User, 
  InsertUser, 
  License, 
  InsertLicense, 
  FaqItem, 
  InsertFaqItem,
  MockTransaction,
  InsertMockTransaction  
} from "@shared/schema";
import { nanoid } from "nanoid";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // License methods
  getLicense(id: number): Promise<License | undefined>;
  getLicenseByKey(key: string): Promise<License | undefined>;
  createLicense(license: InsertLicense): Promise<License>;
  getAllLicenses(): Promise<License[]>;
  updateLicenseStatus(id: number, active: boolean): Promise<License>;
  
  // FAQ methods
  getFaqItems(): Promise<FaqItem[]>;
  getFaqItem(id: number): Promise<FaqItem | undefined>;
  createFaqItem(faqItem: InsertFaqItem): Promise<FaqItem>;
  
  // Mock transactions methods
  getMockTransactions(): Promise<MockTransaction[]>;
  createMockTransaction(transaction: InsertMockTransaction): Promise<MockTransaction>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private licenses: Map<number, License>;
  private faqItems: Map<number, FaqItem>;
  private mockTransactions: Map<number, MockTransaction>;
  private currentId: {
    users: number;
    licenses: number;
    faqItems: number;
    mockTransactions: number;
  };

  constructor() {
    this.users = new Map();
    this.licenses = new Map();
    this.faqItems = new Map();
    this.mockTransactions = new Map();
    this.currentId = {
      users: 1,
      licenses: 1,
      faqItems: 1,
      mockTransactions: 1
    };
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Add some sample FAQ items
    this.createFaqItem({
      question: "What is Levi Flasher?",
      answer: "Levi Flasher is an educational tool designed to simulate USDT transactions on the TRC20 blockchain. It allows users to understand how transactions work without performing actual blockchain operations. This is strictly for educational purposes."
    });
    
    this.createFaqItem({
      question: "Why do I need a license key?",
      answer: "The license key helps us maintain our infrastructure and continue developing educational tools. Your one-time payment of 750 USDT provides lifetime access to all current and future simulators."
    });
    
    this.createFaqItem({
      question: "Is this performing real transactions?",
      answer: "No. Levi Flasher is strictly an educational simulation tool. It does not connect to the actual blockchain or move any real funds. All transactions are simulated within our closed system."
    });
    
    this.createFaqItem({
      question: "When will the BTC flasher be available?",
      answer: "We're targeting a Q2 2023 release for our Bitcoin transaction simulator. Current license holders will automatically gain access at no additional cost."
    });
    
    this.createFaqItem({
      question: "How do I get help if I have questions?",
      answer: "You can use our chatbot in the bottom-right corner for immediate assistance, or email our support team at support@leviflasher.com for more complex inquiries."
    });
    
    // Add some sample mock transactions
    const statuses = ["CONFIRMED", "CONFIRMED", "CONFIRMED", "PENDING", "CONFIRMED"];
    const amounts = ["1,250", "750", "2,500", "850", "1,750"];
    
    for (let i = 0; i < 5; i++) {
      this.createMockTransaction({
        hash: `0x${nanoid(10)}`,
        amount: amounts[i],
        sender: `0x${nanoid(10)}`,
        recipient: `0x${nanoid(10)}`,
        status: statuses[i]
      });
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId.users++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // License methods
  async getLicense(id: number): Promise<License | undefined> {
    return this.licenses.get(id);
  }
  
  async getLicenseByKey(key: string): Promise<License | undefined> {
    return Array.from(this.licenses.values()).find(
      (license) => license.key === key,
    );
  }
  
  async createLicense(insertLicense: InsertLicense): Promise<License> {
    const id = this.currentId.licenses++;
    const now = new Date();
    const license: License = { 
      ...insertLicense, 
      id, 
      active: true,
      createdAt: now.toISOString()
    };
    this.licenses.set(id, license);
    return license;
  }
  
  async getAllLicenses(): Promise<License[]> {
    return Array.from(this.licenses.values());
  }
  
  async updateLicenseStatus(id: number, active: boolean): Promise<License> {
    const license = await this.getLicense(id);
    if (!license) {
      throw new Error(`License with ID ${id} not found`);
    }
    
    const updatedLicense: License = {
      ...license,
      active
    };
    
    this.licenses.set(id, updatedLicense);
    return updatedLicense;
  }
  
  // FAQ methods
  async getFaqItems(): Promise<FaqItem[]> {
    return Array.from(this.faqItems.values());
  }
  
  async getFaqItem(id: number): Promise<FaqItem | undefined> {
    return this.faqItems.get(id);
  }
  
  async createFaqItem(insertFaqItem: InsertFaqItem): Promise<FaqItem> {
    const id = this.currentId.faqItems++;
    const faqItem: FaqItem = { ...insertFaqItem, id };
    this.faqItems.set(id, faqItem);
    return faqItem;
  }
  
  // Mock transactions methods
  async getMockTransactions(): Promise<MockTransaction[]> {
    return Array.from(this.mockTransactions.values());
  }
  
  async createMockTransaction(insertTransaction: InsertMockTransaction): Promise<MockTransaction> {
    const id = this.currentId.mockTransactions++;
    const now = new Date();
    const transaction: MockTransaction = { 
      ...insertTransaction, 
      id,
      timestamp: now.toISOString()
    };
    this.mockTransactions.set(id, transaction);
    return transaction;
  }
}

export const storage = new MemStorage();
