import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { nanoid } from "nanoid";
import { insertLicenseSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes prefix
  const apiPrefix = "/api";

  // Mock transactions endpoint
  app.get(`${apiPrefix}/transactions`, async (_req: Request, res: Response) => {
    try {
      const transactions = await storage.getMockTransactions();
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  // Verify license endpoint
  app.post(`${apiPrefix}/license/verify`, async (req: Request, res: Response) => {
    try {
      const schema = z.object({
        key: z.string().min(10),
      });

      const { key } = schema.parse(req.body);
      const license = await storage.getLicenseByKey(key);

      if (license && license.active) {
        res.json({ valid: true, license });
      } else {
        res.status(401).json({ valid: false, message: "Invalid or inactive license key" });
      }
    } catch (error) {
      res.status(400).json({ valid: false, message: "Invalid request" });
    }
  });

  // Verify payment endpoint
  app.post(`${apiPrefix}/license/verify-payment`, async (req: Request, res: Response) => {
    try {
      const schema = z.object({
        name: z.string().min(2),
        email: z.string().email(),
      });

      const { name, email } = schema.parse(req.body);
      
      // Generate a unique license key
      const licenseKey = `LEVI-${nanoid(16)}`;
      
      // Create the license in storage
      const newLicense = await storage.createLicense({
        name,
        email,
        key: licenseKey,
      });

      // In a real implementation, you would send an email with the license key
      // For this demo, we'll just return success
      res.json({ 
        success: true, 
        message: "Payment verification received. Your license key will be sent to your email." 
      });
    } catch (error) {
      res.status(400).json({ success: false, message: "Invalid request" });
    }
  });

  // Simulate transaction endpoint
  app.post(`${apiPrefix}/simulator/simulate`, async (req: Request, res: Response) => {
    try {
      const schema = z.object({
        sender: z.string().optional(),
        recipient: z.string().optional(),
        amount: z.string().optional(),
        speed: z.enum(["slow", "medium", "fast"]).optional(),
      });

      const data = schema.parse(req.body);
      
      // Generate mock transaction ID
      const txId = `0x${nanoid(8)}`;
      
      // Return success with transaction ID
      res.json({ 
        success: true,
        txId,
        message: "Transaction flash started"
      });
    } catch (error) {
      res.status(400).json({ success: false, message: "Invalid request" });
    }
  });

  // Chatbot endpoint
  app.post(`${apiPrefix}/chatbot`, async (req: Request, res: Response) => {
    try {
      const schema = z.object({
        message: z.string().min(1),
      });

      const { message } = schema.parse(req.body);
      
      // Simple keyword-based responses
      let reply = "I'm not sure how to answer that. Can you ask something about the simulator or licenses?";
      
      const lowerMessage = message.toLowerCase();
      
      if (lowerMessage.includes("license") || lowerMessage.includes("key")) {
        reply = "You can get a license key by sending 750 USDT (TRC20) to our wallet address. After payment, we'll send the key to your email. The license gives you lifetime access to all our simulators.";
      } else if (lowerMessage.includes("payment") || lowerMessage.includes("cost") || lowerMessage.includes("price")) {
        reply = "The license costs 750 USDT on the TRC20 network. This is a one-time payment for lifetime access to all current and future simulators.";
      } else if (lowerMessage.includes("simulator") || lowerMessage.includes("flash")) {
        reply = "Our USDT Transaction Flasher is for educational purposes only. This tool should not be used for scamming purposes, and we will not be held responsible for any damages caused by our tool.";
      } else if (lowerMessage.includes("real") || lowerMessage.includes("actual")) {
        reply = "This tool should not be used for scamming purposes and should only be used for Educational purposes only. We will not be held responsible for any damages caused by our tool.";
      } else if (lowerMessage.includes("bitcoin") || lowerMessage.includes("btc")) {
        reply = "We're working on a Bitcoin Flasher that will be available soon. If you have a license for the USDT Flasher, you'll automatically get access to the BTC Flasher when it's released.";
      } else if (lowerMessage.includes("help") || lowerMessage.includes("support")) {
        reply = "For support, you can email us at support@leviflasher.com or ask specific questions here in the chat.";
      } else if (lowerMessage.includes("hello") || lowerMessage.includes("hi")) {
        reply = "Hello! How can I help you with our transaction flasher today?";
      }
      
      res.json({ reply });
    } catch (error) {
      res.status(400).json({ message: "Invalid request" });
    }
  });

  

  // Admin routes for license management
  app.get(`${apiPrefix}/admin/licenses`, async (_req: Request, res: Response) => {
    try {
      const licenses = await storage.getAllLicenses();
      return res.json(licenses);
    } catch (error) {
      console.error("Error fetching licenses:", error);
      return res.status(500).json({ message: "Failed to fetch licenses" });
    }
  });

  app.post(`${apiPrefix}/admin/licenses/toggle/:id`, async (req: Request, res: Response) => {
    try {
      const licenseId = parseInt(req.params.id);
      if (isNaN(licenseId)) {
        return res.status(400).json({ message: "Invalid license ID" });
      }
      
      const license = await storage.getLicense(licenseId);
      if (!license) {
        return res.status(404).json({ message: "License not found" });
      }
      
      const updatedLicense = await storage.updateLicenseStatus(licenseId, !license.active);
      return res.json(updatedLicense);
    } catch (error) {
      console.error("Error toggling license status:", error);
      return res.status(500).json({ message: "Failed to update license" });
    }
  });

  app.post(`${apiPrefix}/admin/licenses/create`, async (req: Request, res: Response) => {
    try {
      const licenseData = insertLicenseSchema.parse(req.body);
      const newLicense = await storage.createLicense(licenseData);
      return res.status(201).json(newLicense);
    } catch (error) {
      console.error("Error creating license:", error);
      return res.status(400).json({ message: "Failed to create license" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
